const assert = require('node:assert/strict');
global.window = global;
require('../core.js');
const C = global.MH_CORE;

assert.deepEqual(C.coordinates(800, -240, 'overworld'), { x: 100, z: -30 });
assert.deepEqual(C.coordinates(100, -30, 'nether'), { x: 800, z: -240 });
assert.equal(C.distance([0, 0, 0, 10, 0, 10]), Math.sqrt(200));
assert.equal(C.experienceTotal(16), 352);
assert.equal(C.experienceTotal(17), 394);
assert.equal(C.experienceTotal(30), 1395);
assert.equal(C.experienceTotal(31), 1507);
assert.equal(C.experienceTotal(32), 1628);
assert.equal(C.fuelUnits(100, 8), 13);
assert.equal(C.fuelUnits(100, 80), 2);
assert.equal(C.craftRuns(64, 4), 16);
assert.deepEqual(C.craftMaterials(10, 4, [{ name: 'Уголь', count: 1 }, { name: 'Палка', count: 1 }]), {
  runs: 3, crafted: 12, requested: 10, leftover: 2,
  materials: [{ name: 'Уголь', count: 1, total: 3, stacks: 0, remainder: 3 }, { name: 'Палка', count: 1, total: 3, stacks: 0, remainder: 3 }]
});
assert.equal(C.craftMaterials(65, 1, [{ name: 'Доски', count: 4 }]).materials[0].stacks, 4);
assert.equal(C.craftMaterials(65, 1, [{ name: 'Доски', count: 4 }]).materials[0].remainder, 4);
assert.throws(() => C.craftMaterials(0, 1, [{ name: 'x', count: 1 }]));
assert.throws(() => C.craftMaterials(2, 1, []));
assert.equal(C.buildBlocks([10, 5, 10]), 500);
assert.throws(() => C.coordinates(Infinity, 0, 'overworld'));
assert.throws(() => C.distance([0, 0, 0, NaN, 0, 0]));
assert.throws(() => C.buildBlocks([1000000, 1000000, 1000000]));
assert.throws(() => C.experienceTotal(1000001));
assert.throws(() => C.fuelUnits(-1, 8));

console.log('MineHelper core tests passed (22 assertions).');

